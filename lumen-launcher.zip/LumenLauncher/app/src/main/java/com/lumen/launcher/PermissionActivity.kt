package com.lumen.launcher

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** First-run permission screen. Also reachable later from Lumen Settings. */
class PermissionActivity : Activity() {

    private data class Group(val title: String, val why: String, val perms: List<String>)

    private fun groups(): List<Group> {
        val g = mutableListOf(
            Group("Contacts", "Show and edit your real contacts in Phone and Contacts.",
                listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)),
            Group("Phone & Calls", "Place calls and show your call history and carrier.",
                listOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_PHONE_STATE)),
            Group("Messages", "Read your text conversations and send SMS.",
                listOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS)),
            Group("Photos & Videos", "Show your real gallery in Photos.",
                if (Build.VERSION.SDK_INT >= 33)
                    listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
                else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)),
            Group("Camera & Microphone", "Take photos, scan and record.",
                listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)),
            Group("Calendar", "Show your real events in Calendar and the widget.",
                listOf(Manifest.permission.READ_CALENDAR)),
            Group("Nearby devices & Location", "Show Wi-Fi and Bluetooth names in Settings and Control Center.",
                buildList {
                    add(Manifest.permission.ACCESS_FINE_LOCATION)
                    if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
                }),
        )
        if (Build.VERSION.SDK_INT >= 33)
            g.add(Group("Notifications", "Show notifications on the Lock Screen.", listOf(Manifest.permission.POST_NOTIFICATIONS)))
        return g
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.parseColor("#0B0B12")
        build()
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B0B12"))
            setPadding(dp(24), dp(56), dp(24), dp(24))
        }
        val icon = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(84), dp(84)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        }
        root.addView(icon)
        root.addView(text("Welcome to Lumen", 28f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(6))
        })
        root.addView(text("Lumen needs a few permissions so Phone, Messages, Photos and Settings show your real content. You can change these any time.", 15f, Color.parseColor("#A0A0B0"), false).apply {
            gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(18))
        })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (g in groups()) list.addView(row(g.title, g.why, g.perms.all { granted(it) }))
        val writeOk = Settings.System.canWrite(this)
        list.addView(row("System settings", "Let Control Center change screen brightness.", writeOk))
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val allow = button("Allow Permissions", true)
        allow.setOnClickListener {
            val need = groups().flatMap { it.perms }.filter { !granted(it) }.toTypedArray()
            if (need.isNotEmpty()) requestPermissions(need, 7)
            else if (!Settings.System.canWrite(this)) openWriteSettings()
            else finishSetup()
        }
        root.addView(allow, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) })

        val home = button("Set Lumen as Home app", false)
        home.setOnClickListener { askHomeRole() }
        root.addView(home, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })

        val done = text("Continue", 16f, Color.parseColor("#0A84FF"), true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(14), 0, 0)
            setOnClickListener { finishSetup() }
        }
        root.addView(done)
        setContentView(root)
    }

    private fun openWriteSettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        } catch (e: Exception) { finishSetup() }
    }

    private fun askHomeRole() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(Context.ROLE_SERVICE) as RoleManager
                if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 9)
                    return
                }
            }
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (!Settings.System.canWrite(this)) openWriteSettings() else build()
    }

    private fun finishSetup() {
        getSharedPreferences("lumen", MODE_PRIVATE).edit().putBoolean("onboarded", true).apply()
        if (!intent.getBooleanExtra("manual", false)) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
        }
        finish()
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun row(title: String, why: String, ok: Boolean): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.parseColor("#17171F")) }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text(title, 16f, Color.WHITE, true))
        col.addView(text(why, 13f, Color.parseColor("#9A9AAA"), false))
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(text(if (ok) "Allowed" else "Needed", 13f, if (ok) Color.parseColor("#30D158") else Color.parseColor("#FF9F0A"), true))
        return r
    }

    private fun button(label: String, primary: Boolean) = TextView(this).apply {
        text = label; textSize = 16f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (primary) Color.WHITE else Color.parseColor("#0A84FF"))
        background = GradientDrawable().apply {
            cornerRadius = dp(26).toFloat()
            setColor(if (primary) Color.parseColor("#0A84FF") else Color.parseColor("#17171F"))
        }
    }
}
