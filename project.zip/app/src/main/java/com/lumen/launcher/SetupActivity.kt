package com.lumen.launcher

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject

class SetupActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var out: TextView
    private val cmd = "pm grant com.lumen.launcher android.permission.WRITE_SECURE_SETTINGS"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float, color: Int = Color.WHITE): TextView = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); setPadding(0, dp(6), 0, dp(6))
    }

    private fun btn(t: String, f: () -> Unit): Button = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f(); refresh() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(32))
        }
        col.addView(tv("Lumen Setup", 28f))
        info = tv("", 14f, Color.LTGRAY); col.addView(info)
        col.addView(btn("1. Set Lumen as default home") { Sys.requestHome(this) })
        col.addView(btn("2. Grant app permissions (camera, mic, contacts, phone...)") { askPerms() })
        col.addView(btn("3. Enable gesture service") {
            if (!Sys.enableSvc(this)) {
                out.text = "Secure-settings permission missing, opening Accessibility settings. Turn on 'Lumen' there."
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else out.text = "Gesture service enabled."
        })
        col.addView(btn("Toggle own edge gestures (on/off)") {
            val on = !Sys.ownGestures(this)
            Sys.prefs(this).edit().putBoolean("own", on).apply()
            if (on) Sys.enableSvc(this)
            NavService.refresh()
            out.text = "Own gestures: " + (if (on) "ON" else "OFF")
        })
        col.addView(tv("System gesture fix (try Xiaomi full-screen gestures). Use this OR own gestures, not both.", 13f, Color.LTGRAY))
        col.addView(btn("Try system gesture fix: ON") { out.text = Sys.navFix(this, true) })
        col.addView(btn("System gesture fix: OFF") { out.text = Sys.navFix(this, false) })
        col.addView(tv("Needed once for the fix and auto-enable (run in Termux with adb, wireless debugging):", 13f, Color.LTGRAY))
        col.addView(tv(cmd, 12f, Color.parseColor("#64D2FF")))
        col.addView(btn("Copy grant command") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("cmd", cmd))
            out.text = "Copied."
        })
        out = tv("", 13f, Color.parseColor("#30D158")); col.addView(out)
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(col) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun askPerms() {
        val l = arrayListOf(
            Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) { l.add(Manifest.permission.POST_NOTIFICATIONS); l.add(Manifest.permission.READ_MEDIA_IMAGES) }
        if (Build.VERSION.SDK_INT >= 31) l.add(Manifest.permission.BLUETOOTH_CONNECT)
        requestPermissions(l.toTypedArray(), 1)
    }

    private fun refresh() {
        val s = JSONObject(Sys.status(this))
        fun ok(b: Boolean) = if (b) "yes" else "NO"
        info.text = "Device: ${s.getString("model")}\nAndroid ${s.getString("android")}\n" +
            "HyperOS/MIUI: ${s.getString("os").trim()} ${s.getString("miui")}\n\n" +
            "Default home: ${ok(s.getBoolean("defaultHome"))}\n" +
            "Gesture service on: ${ok(s.getBoolean("service"))}\n" +
            "Secure-settings access: ${ok(s.getBoolean("secure"))}\n" +
            "Own edge gestures: ${ok(s.getBoolean("own"))}\n" +
            "force_fsg_nav_bar: ${s.getInt("fsg")}   hide_gesture_line: ${s.getInt("hideLine")}"
    }
}
