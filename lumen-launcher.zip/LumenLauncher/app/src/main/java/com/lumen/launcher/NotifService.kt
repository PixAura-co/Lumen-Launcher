package com.lumen.launcher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

class NotifService : NotificationListenerService() {
    companion object {
        var inst: NotifService? = null
        fun list(): JSONArray {
            val out = JSONArray()
            val s = inst ?: return out
            try {
                for (n in s.activeNotifications) {
                    if (n.packageName == "com.lumen.launcher" || n.isOngoing && n.notification.flags and android.app.Notification.FLAG_FOREGROUND_SERVICE != 0) continue
                    val e = n.notification.extras
                    val title = e.getCharSequence("android.title")?.toString() ?: ""
                    val text = (e.getCharSequence("android.bigText") ?: e.getCharSequence("android.text"))?.toString() ?: ""
                    if (title.isEmpty() && text.isEmpty()) continue
                    out.put(JSONObject().put("key", n.key).put("pkg", n.packageName).put("t", title).put("x", text).put("ts", n.postTime))
                }
            } catch (_: Exception) {}
            return out
        }
        fun dismiss(key: String) { try { inst?.cancelNotification(key) } catch (_: Exception) {} }
        fun open(key: String) {
            try { inst?.activeNotifications?.firstOrNull { it.key == key }?.notification?.contentIntent?.send() } catch (_: Exception) {}
        }
    }
    override fun onListenerConnected() { inst = this }
    override fun onListenerDisconnected() { if (inst === this) inst = null }
    override fun onNotificationPosted(sbn: StatusBarNotification?) {}
    override fun onNotificationRemoved(sbn: StatusBarNotification?) {}
}
