package com.lumen.launcher

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

class NavService : AccessibilityService() {
    companion object {
        var inst: NavService? = null
        fun act(name: String): Boolean {
            val s = inst ?: return false
            val a = when (name) {
                "home" -> GLOBAL_ACTION_HOME
                "back" -> GLOBAL_ACTION_BACK
                "recents" -> GLOBAL_ACTION_RECENTS
                "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
                "quick" -> GLOBAL_ACTION_QUICK_SETTINGS
                "power" -> GLOBAL_ACTION_POWER_DIALOG
                "lock" -> GLOBAL_ACTION_LOCK_SCREEN
                "screenshot" -> GLOBAL_ACTION_TAKE_SCREENSHOT
                else -> return false
            }
            return s.performGlobalAction(a)
        }
        fun refresh() { inst?.rebuild() }
    }

    private lateinit var wm: WindowManager
    private val views = mutableListOf<View>()
    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        inst = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        rebuild()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { clear(); inst = null; return super.onUnbind(i) }
    override fun onDestroy() { clear(); inst = null; super.onDestroy() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun clear() {
        for (v in views) try { wm.removeView(v) } catch (e: Exception) { }
        views.clear()
    }

    fun rebuild() {
        clear()
        if (!Sys.ownGestures(this)) return
        val dm = resources.displayMetrics
        add(Bottom(), WindowManager.LayoutParams.MATCH_PARENT, dp(28), Gravity.BOTTOM, 0)
        val eh = (dm.heightPixels * 0.55f).toInt()
        add(Edge(true), dp(16), eh, Gravity.START or Gravity.BOTTOM, dp(150))
        add(Edge(false), dp(16), eh, Gravity.END or Gravity.BOTTOM, dp(150))
    }

    private fun add(v: View, w: Int, hh: Int, g: Int, y: Int) {
        val lp = WindowManager.LayoutParams(
            w, hh, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = g
        lp.y = y
        try { wm.addView(v, lp); views.add(v) } catch (e: Exception) { }
    }

    /** Bottom strip: swipe up = Home, swipe up and hold = Recents. Draws the home pill. */
    @SuppressLint("ViewConstructor")
    private inner class Bottom : View(this@NavService) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; alpha = 130 }
        private var y0 = 0f
        private var armed = false
        private var fired = false
        private val hold = Runnable {
            fired = true
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            performGlobalAction(GLOBAL_ACTION_RECENTS)
        }

        override fun onDraw(c: Canvas) {
            val w = dp(110).toFloat(); val t = dp(4).toFloat()
            val l = (width - w) / 2f; val b = height - dp(6).toFloat()
            c.drawRoundRect(RectF(l, b - t, l + w, b), t, t, p)
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { y0 = e.rawY; armed = false; fired = false }
                MotionEvent.ACTION_MOVE -> if (!fired) {
                    val up = y0 - e.rawY
                    if (!armed && up > dp(48)) { armed = true; h.postDelayed(hold, 320) }
                    else if (armed && up < dp(24)) { armed = false; h.removeCallbacks(hold) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    h.removeCallbacks(hold)
                    if (armed && !fired && e.actionMasked == MotionEvent.ACTION_UP) {
                        performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        performGlobalAction(GLOBAL_ACTION_HOME)
                    }
                    armed = false
                }
            }
            return true
        }
    }

    /** Side strips: swipe inward = Back. */
    @SuppressLint("ViewConstructor")
    private inner class Edge(val left: Boolean) : View(this@NavService) {
        private var x0 = 0f
        private var fired = false

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { x0 = e.rawX; fired = false }
                MotionEvent.ACTION_MOVE -> if (!fired) {
                    val d = if (left) e.rawX - x0 else x0 - e.rawX
                    if (d > dp(56) && abs(d) > 0) {
                        fired = true
                        performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        performGlobalAction(GLOBAL_ACTION_BACK)
                    }
                }
            }
            return true
        }
    }
}
