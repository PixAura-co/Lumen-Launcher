package com.lumen.launcher

import android.app.Activity
import android.app.ActivityManager
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.util.Base64
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

object Sys {
    const val SECURE = "android.permission.WRITE_SECURE_SETTINGS"

    fun prefs(c: Context) = c.getSharedPreferences("lumen", Context.MODE_PRIVATE)
    fun ownGestures(c: Context) = prefs(c).getBoolean("own", true)

    fun hasSecure(c: Context) = c.checkSelfPermission(SECURE) == PackageManager.PERMISSION_GRANTED

    private fun svcLong(c: Context) = ComponentName(c, NavService::class.java).flattenToString()
    private fun svcShort(c: Context) = ComponentName(c, NavService::class.java).flattenToShortString()

    fun svcEnabled(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.split(':').any { it.equals(svcLong(c), true) || it.equals(svcShort(c), true) }
    }

    /** Needs WRITE_SECURE_SETTINGS. Turns the gesture service on without opening Settings. */
    fun enableSvc(c: Context): Boolean {
        if (!hasSecure(c)) return false
        return try {
            val cr = c.contentResolver
            if (!svcEnabled(c)) {
                val cur = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
                val n = if (cur.isEmpty()) svcLong(c) else cur + ":" + svcLong(c)
                Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, n)
            }
            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        } catch (e: Exception) { false }
    }

    fun isDefaultHome(c: Context): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val r = c.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
        return r?.activityInfo?.packageName == c.packageName
    }

    fun requestHome(a: Activity) {
        try {
            val rm = a.getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                a.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 91)
                return
            }
        } catch (e: Exception) { }
        try { a.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch (e: Exception) {
            a.startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    /** Tries the MIUI/HyperOS full-screen-gesture switches. Returns per-key result. */
    fun navFix(c: Context, on: Boolean): String {
        val v = if (on) 1 else 0
        val r = JSONObject()
        for (k in listOf("force_fsg_nav_bar", "hide_gesture_line")) {
            r.put(k, try { Settings.Global.putInt(c.contentResolver, k, v); "ok" }
            catch (e: Exception) { e.javaClass.simpleName })
        }
        return r.toString()
    }

    private fun prop(k: String): String = try {
        Class.forName("android.os.SystemProperties").getMethod("get", String::class.java).invoke(null, k) as String
    } catch (e: Exception) { "" }

    fun status(c: Context): String {
        val o = JSONObject()
        o.put("defaultHome", isDefaultHome(c))
        o.put("service", svcEnabled(c))
        o.put("secure", hasSecure(c))
        o.put("own", ownGestures(c))
        o.put("fsg", Settings.Global.getInt(c.contentResolver, "force_fsg_nav_bar", -1))
        o.put("hideLine", Settings.Global.getInt(c.contentResolver, "hide_gesture_line", -1))
        o.put("model", Build.MANUFACTURER + " " + Build.MODEL)
        o.put("android", Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")")
        o.put("os", prop("ro.mi.os.version.name") + " " + prop("ro.mi.os.version.incremental"))
        o.put("miui", prop("ro.miui.ui.version.name"))
        o.put("build", Build.DISPLAY)
        return o.toString()
    }

    fun appsJson(c: Context): String {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val arr = JSONArray()
        pm.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != c.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .forEach {
                arr.put(JSONObject().put("n", it.loadLabel(pm).toString()).put("p", it.activityInfo.packageName))
            }
        return arr.toString()
    }

    fun iconB64(c: Context, pkg: String): String = try {
        val bmp = c.packageManager.getApplicationIcon(pkg).toBitmap(120, 120)
        val bo = ByteArrayOutputStream()
        bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, bo)
        "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    } catch (e: Exception) { "" }

    fun launch(c: Context, pkg: String): Boolean {
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
        return true
    }

    fun sysJson(c: Context): String {
        val o = JSONObject()
        val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            o.put("battery", if (lvl >= 0) lvl * 100 / sc else -1)
            val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            o.put("charging", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL)
            o.put("batteryTemp", b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0)
        }
        try {
            val cm = c.getSystemService(ConnectivityManager::class.java)
            val cap = cm.getNetworkCapabilities(cm.activeNetwork)
            o.put("wifi", cap?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true)
            o.put("cellular", cap?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true)
            o.put("online", cap?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true)
        } catch (e: Exception) { }
        try {
            val mi = ActivityManager.MemoryInfo()
            c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
            o.put("ramTotal", mi.totalMem); o.put("ramFree", mi.availMem)
            val sf = StatFs(Environment.getDataDirectory().path)
            o.put("diskTotal", sf.totalBytes); o.put("diskFree", sf.availableBytes)
        } catch (e: Exception) { }
        try {
            o.put("brightness", Settings.System.getInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255.0)
        } catch (e: Exception) { }
        try {
            val am = c.getSystemService(android.media.AudioManager::class.java)
            val m = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
            o.put("volume", am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC).toDouble() / m)
        } catch (e: Exception) { }
        o.put("model", Build.MODEL); o.put("device", Build.MANUFACTURER)
        o.put("android", Build.VERSION.RELEASE)
        o.put("tz", java.util.TimeZone.getDefault().id)
        return o.toString()
    }
}
