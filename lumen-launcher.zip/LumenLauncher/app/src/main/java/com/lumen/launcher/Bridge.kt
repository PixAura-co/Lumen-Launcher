package com.lumen.launcher

import android.Manifest
import android.app.ActivityManager
import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.StatFs
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.AlarmClock
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject

/** Everything the Lumen UI (HTML) can ask the phone for. All methods return JSON strings. */
class Bridge(private val a: MainActivity) {

    private val ctx: Context = a.applicationContext
    private val cr: ContentResolver get() = ctx.contentResolver

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun ok(v: Any?) = JSONObject().put("ok", v ?: true).toString()
    private fun ui(f: () -> Unit) = a.runOnUiThread { try { f() } catch (_: Exception) {} }
    private fun start(i: Intent) = ui { a.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    private fun digits(s: String?) = (s ?: "").filter { it.isDigit() }.takeLast(9)

    // ---------------------------------------------------------------- permissions
    @JavascriptInterface fun perms(): String = JSONObject().apply {
        put("contacts", has(Manifest.permission.READ_CONTACTS))
        put("calls", has(Manifest.permission.READ_CALL_LOG))
        put("sms", has(Manifest.permission.READ_SMS))
        put("photos", if (Build.VERSION.SDK_INT >= 33) has(Manifest.permission.READ_MEDIA_IMAGES) else has(Manifest.permission.READ_EXTERNAL_STORAGE))
        put("camera", has(Manifest.permission.CAMERA))
        put("write", Settings.System.canWrite(ctx))
    }.toString()

    @JavascriptInterface fun openPermissions(): String {
        ui { a.startActivity(Intent(a, PermissionActivity::class.java).putExtra("manual", true)) }
        return ok(true)
    }

    // ---------------------------------------------------------------- device + status
    @JavascriptInterface fun device(): String {
        val st = StatFs(ctx.filesDir.absolutePath)
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val dm = ctx.resources.displayMetrics
        return JSONObject().apply {
            put("model", Build.MODEL); put("brand", Build.MANUFACTURER); put("device", Build.DEVICE)
            put("android", Build.VERSION.RELEASE); put("sdk", Build.VERSION.SDK_INT)
            put("patch", if (Build.VERSION.SDK_INT >= 23) Build.VERSION.SECURITY_PATCH else "")
            put("build", Build.DISPLAY)
            put("storageTotal", st.totalBytes); put("storageFree", st.availableBytes)
            put("ram", mi.totalMem); put("ramFree", mi.availMem)
            put("screen", "${dm.widthPixels} x ${dm.heightPixels}"); put("density", dm.densityDpi)
            put("uptime", SystemClock.elapsedRealtime())
            put("carrier", tm.networkOperatorName ?: "")
            put("name", Settings.Global.getString(cr, "device_name") ?: Build.MODEL)
        }.toString()
    }

    @JavascriptInterface fun status(): String {
        val o = JSONObject()
        try {
            val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lv = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            val sc = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val stt = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, 0) ?: 0
            o.put("bat", lv * 100 / sc)
            o.put("chg", stt == BatteryManager.BATTERY_STATUS_CHARGING || stt == BatteryManager.BATTERY_STATUS_FULL)
        } catch (_: Exception) {}
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            o.put("wifi", wm.isWifiEnabled)
            o.put("wifiOn", caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true)
            o.put("cell", caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true)
            if (wm.isWifiEnabled) {
                @Suppress("DEPRECATION") val ci = wm.connectionInfo
                o.put("wifiBars", WifiManager.calculateSignalLevel(ci.rssi, 4))
            }
        } catch (_: Exception) {}
        try {
            val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            o.put("bt", bm.adapter?.isEnabled == true)
        } catch (_: Exception) {}
        try {
            val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            o.put("carrier", tm.networkOperatorName ?: "")
            if (Build.VERSION.SDK_INT >= 28 && has(Manifest.permission.READ_PHONE_STATE)) {
                o.put("bars", tm.signalStrength?.level ?: 0)
            }
        } catch (_: Exception) {}
        try { o.put("air", Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0) == 1) } catch (_: Exception) {}
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            o.put("dnd", nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL)
        } catch (_: Exception) {}
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            o.put("vol", am.getStreamVolume(AudioManager.STREAM_MUSIC).toDouble() / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
            o.put("ringer", am.ringerMode)
        } catch (_: Exception) {}
        try { o.put("bright", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128) / 255.0) } catch (_: Exception) {}
        return o.toString()
    }

    // ---------------------------------------------------------------- contacts / calls / sms / photos
    private fun contactList(): JSONArray {
        val out = JSONArray()
        if (!has(Manifest.permission.READ_CONTACTS)) return out
        val emails = HashMap<String, String>()
        cr.query(ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Email.CONTACT_ID, ContactsContract.CommonDataKinds.Email.ADDRESS),
            null, null, null)?.use { c -> while (c.moveToNext()) emails.putIfAbsent(c.getString(0), c.getString(1) ?: "") }
        val seen = HashSet<String>()
        cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.CONTACT_ID, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.STARRED),
            null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                if (!seen.add(id)) continue
                out.put(JSONObject().put("n", c.getString(1) ?: "").put("p", c.getString(2) ?: "")
                    .put("e", emails[id] ?: "").put("f", c.getInt(3) == 1))
            }
        }
        return out
    }
    @JavascriptInterface fun contacts(): String = contactList().toString()

    @JavascriptInterface fun calls(): String {
        val out = JSONArray()
        if (!has(Manifest.permission.READ_CALL_LOG)) return out.toString()
        val q = Bundle().apply {
            putInt(ContentResolver.QUERY_ARG_LIMIT, 150)
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(CallLog.Calls.DATE))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
        }
        cr.query(CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls.TYPE), q, null)?.use { c ->
            while (c.moveToNext()) {
                val dir = when (c.getInt(4)) { 1 -> "in"; 2 -> "out"; else -> "miss" }
                out.put(JSONObject().put("p", c.getString(0) ?: "").put("n", c.getString(1) ?: "")
                    .put("t", c.getLong(2)).put("dur", c.getInt(3)).put("dir", dir))
            }
        }
        return out.toString()
    }

    @JavascriptInterface fun sms(): String {
        val out = JSONArray()
        if (!has(Manifest.permission.READ_SMS)) return out.toString()
        val names = HashMap<String, String>()
        val cl = contactList()
        for (i in 0 until cl.length()) { val c = cl.getJSONObject(i); names.putIfAbsent(digits(c.getString("p")), c.getString("n")) }
        val q = Bundle().apply {
            putInt(ContentResolver.QUERY_ARG_LIMIT, 800)
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(Telephony.Sms.DATE))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
        }
        val threads = LinkedHashMap<String, JSONObject>()
        cr.query(Telephony.Sms.CONTENT_URI, arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms.READ), q, null)?.use { c ->
            while (c.moveToNext()) {
                val addr = c.getString(0) ?: continue
                val key = digits(addr).ifEmpty { addr }
                val t = threads.getOrPut(key) {
                    JSONObject().put("addr", addr).put("n", names[key] ?: addr).put("u", 0).put("m", JSONArray())
                }
                val type = c.getInt(3)
                if (type == 1 && c.getInt(4) == 0) t.put("u", t.getInt("u") + 1)
                val m = t.getJSONArray("m")
                if (m.length() < 40) m.put(JSONObject().put("t", c.getString(1) ?: "").put("ts", c.getLong(2)).put("me", if (type == 1) 0 else 1))
            }
        }
        for (t in threads.values) {
            val m = t.getJSONArray("m"); val r = JSONArray()
            for (i in m.length() - 1 downTo 0) r.put(m.get(i)); t.put("m", r); out.put(t)
        }
        return out.toString()
    }

    @JavascriptInterface fun sendSms(to: String, text: String): String {
        return try {
            val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
            sm.sendMultipartTextMessage(to, null, sm.divideMessage(text), null, null); ok(true)
        } catch (e: Exception) { ok(false) }
    }

    @JavascriptInterface fun photos(limit: Int): String {
        val out = JSONArray()
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (!has(perm)) return out.toString()
        val q = Bundle().apply {
            putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(MediaStore.Images.Media.DATE_ADDED))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
        }
        cr.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED), q, null)?.use { c ->
            while (c.moveToNext()) out.put(JSONObject().put("id", c.getLong(0)).put("t", c.getLong(1) * 1000)
                .put("u", "https://appassets.androidplatform.net/media/" + c.getLong(0)))
        }
        return out.toString()
    }

    // ---------------------------------------------------------------- apps
    @JavascriptInterface fun apps(): String {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val arr = JSONArray()
        pm.queryIntentActivities(i, 0).sortedBy { it.loadLabel(pm).toString().lowercase() }.forEach {
            arr.put(JSONObject().put("pkg", it.activityInfo.packageName).put("label", it.loadLabel(pm).toString()))
        }
        return arr.toString()
    }

    @JavascriptInterface fun candidates(kind: String): String {
        val pm = ctx.packageManager
        val i = when (kind) {
            "phone" -> Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))
            "sms" -> Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))
            "camera" -> Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
            "gallery" -> Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse("content://media/external/images/media/1"), "image/*")
            "contacts" -> Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)
            "clock" -> Intent(AlarmClock.ACTION_SHOW_ALARMS)
            "calendar" -> Intent(Intent.ACTION_VIEW, Uri.parse("content://com.android.calendar/time"))
            "music" -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC)
            "browser" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
            "calc" -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)
            "files" -> Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
            else -> return apps()
        }
        val arr = JSONArray(); val seen = HashSet<String>()
        pm.queryIntentActivities(i, 0).forEach {
            val p = it.activityInfo.packageName
            if (p != ctx.packageName && seen.add(p)) arr.put(JSONObject().put("pkg", p).put("label", it.loadLabel(pm).toString()))
        }
        return arr.toString()
    }

    @JavascriptInterface fun launch(pkg: String): String {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return ok(false)
        start(i); return ok(true)
    }

    // ---------------------------------------------------------------- actions
    @JavascriptInterface fun call(num: String): String {
        val uri = Uri.parse("tel:" + Uri.encode(num))
        start(Intent(if (has(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri)); return ok(true)
    }

    @JavascriptInterface fun openUrl(u: String): String { start(Intent(Intent.ACTION_VIEW, Uri.parse(u))); return ok(true) }

    @JavascriptInterface fun share(text: String): String {
        start(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null)); return ok(true)
    }

    /** Opens the right Android system panel/settings page. Android does not let apps flip radios silently. */
    @JavascriptInterface fun panel(k: String): String {
        val q = Build.VERSION.SDK_INT >= 29
        val act = when (k) {
            "wifi" -> if (q) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS
            "cell" -> if (q) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_DATA_ROAMING_SETTINGS
            "air" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "bt" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "dnd" -> Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS
            "volume" -> if (q) Settings.Panel.ACTION_VOLUME else Settings.ACTION_SOUND_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "notif" -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "security" -> Settings.ACTION_SECURITY_SETTINGS
            "access" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "lang" -> Settings.ACTION_LOCALE_SETTINGS
            "nfc" -> Settings.ACTION_NFC_SETTINGS
            "about" -> Settings.ACTION_DEVICE_INFO_SETTINGS
            "dev" -> Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
            "home" -> Settings.ACTION_HOME_SETTINGS
            "hotspot" -> "android.settings.TETHER_SETTINGS"
            "cast" -> Settings.ACTION_CAST_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        start(Intent(act).apply { if (k == "notif") putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName) }); return ok(true)
    }

    @JavascriptInterface fun torch(on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            cm.setTorchMode(id, on); ok(true)
        } catch (e: Exception) { ok(false) }
    }

    @JavascriptInterface fun setVolume(f: Double): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(f * am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).toInt(), 0); return ok(true)
    }

    @JavascriptInterface fun setBrightness(f: Double): String {
        val v = (f.coerceIn(0.02, 1.0) * 255).toInt()
        if (Settings.System.canWrite(ctx)) {
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, v)
        } else ui {
            val lp = a.window.attributes; lp.screenBrightness = f.toFloat().coerceIn(0.02f, 1f); a.window.attributes = lp
        }
        return ok(true)
    }

    @JavascriptInterface fun setRinger(silent: Boolean): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return try { am.ringerMode = if (silent) AudioManager.RINGER_MODE_VIBRATE else AudioManager.RINGER_MODE_NORMAL; ok(true) } catch (e: Exception) { ok(false) }
    }

    @JavascriptInterface fun vibrate(ms: Int): String {
        val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE)) else @Suppress("DEPRECATION") v.vibrate(ms.toLong())
        return ok(true)
    }

    @JavascriptInterface fun notifs(): String = NotifService.list().toString()
    @JavascriptInterface fun notifAccess(): String {
        val en = android.provider.Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: ""
        return JSONObject().put("ok", en.contains(ctx.packageName)).toString()
    }
    @JavascriptInterface fun openNotifAccess(): String { start(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")); return ok(true) }
    @JavascriptInterface fun dismissNotif(key: String): String { NotifService.dismiss(key); return ok(true) }
    @JavascriptInterface fun openNotif(key: String): String { NotifService.open(key); return ok(true) }
}
