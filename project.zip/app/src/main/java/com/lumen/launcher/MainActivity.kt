package com.lumen.launcher

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingPerm: PermissionRequest? = null

    private val pkgRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { js("window.dispatchEvent(new Event('lumen-apps'))") }
    }

    private fun js(code: String) { runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(code, null) } }

    private val closeApp = "try{if(typeof cur!=='undefined'&&cur&&typeof closeApp==='function')closeApp()}catch(e){}"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        immersive()

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()

        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isLongClickable = false
        web.setOnLongClickListener { true }
        web.isHapticFeedbackEnabled = false
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            textZoom = 100
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.host == "appassets.androidplatform.net") return false
                openExternal(u.toString()); return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) {
                runOnUiThread {
                    val need = ArrayList<String>()
                    for (res in r.resources) {
                        if (res == PermissionRequest.RESOURCE_VIDEO_CAPTURE) need.add(Manifest.permission.CAMERA)
                        if (res == PermissionRequest.RESOURCE_AUDIO_CAPTURE) need.add(Manifest.permission.RECORD_AUDIO)
                    }
                    val miss = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                    if (miss.isEmpty()) r.grant(r.resources)
                    else { pendingPerm = r; requestPermissions(miss.toTypedArray(), 5) }
                }
            }
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                val i = Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
                return try { startActivityForResult(Intent.createChooser(i, "Select"), 77); true }
                catch (e: Exception) { fileCb = null; false }
            }
            override fun onCreateWindow(v: WebView, d: Boolean, u: Boolean, m: Message): Boolean {
                val t = WebView(this@MainActivity)
                t.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(x: WebView, url: String, f: android.graphics.Bitmap?) {
                        if (url != "about:blank") { openExternal(url); x.stopLoading(); x.destroy() }
                    }
                    override fun shouldOverrideUrlLoading(x: WebView, r: WebResourceRequest): Boolean {
                        openExternal(r.url.toString()); return true
                    }
                }
                (m.obj as WebView.WebViewTransport).webView = t
                m.sendToTarget()
                return true
            }
        }
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgRx, f, Context.RECEIVER_EXPORTED) else registerReceiver(pkgRx, f)
        if (Sys.ownGestures(this)) Sys.enableSvc(this)
    }

    private fun openExternal(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }

    @Suppress("DEPRECATION")
    private fun immersive() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    override fun onWindowFocusChanged(has: Boolean) { super.onWindowFocusChanged(has); if (has) immersive() }

    override fun onResume() {
        super.onResume()
        immersive()
        if (Sys.ownGestures(this) && !Sys.svcEnabled(this)) Sys.enableSvc(this)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        if (i.action == Intent.ACTION_MAIN) js(closeApp)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() { js(closeApp) }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 77) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d)); fileCb = null
        }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (rc == 5) {
            val req = pendingPerm; pendingPerm = null
            if (req != null) {
                if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) req.grant(req.resources) else req.deny()
            }
        }
    }

    override fun onDestroy() { try { unregisterReceiver(pkgRx) } catch (e: Exception) { }; super.onDestroy() }

    /** window.Android.* from the HTML. */
    inner class Bridge {
        @JavascriptInterface fun apps(): String = Sys.appsJson(this@MainActivity)
        @JavascriptInterface fun icon(pkg: String): String = Sys.iconB64(this@MainActivity, pkg)
        @JavascriptInterface fun launch(pkg: String): Boolean = Sys.launch(this@MainActivity, pkg)
        @JavascriptInterface fun sys(): String = Sys.sysJson(this@MainActivity)
        @JavascriptInterface fun status(): String = Sys.status(this@MainActivity)
        @JavascriptInterface fun action(n: String): Boolean = NavService.act(n)
        @JavascriptInterface fun navFix(on: Boolean): String = Sys.navFix(this@MainActivity, on)
        @JavascriptInterface fun ownGestures(on: Boolean) {
            Sys.prefs(this@MainActivity).edit().putBoolean("own", on).apply()
            if (on) Sys.enableSvc(this@MainActivity)
            NavService.refresh()
        }
        @JavascriptInterface fun setup() { startActivity(Intent(this@MainActivity, SetupActivity::class.java)) }
        @JavascriptInterface fun defaultHome() { runOnUiThread { Sys.requestHome(this@MainActivity) } }
        @JavascriptInterface fun appInfo(pkg: String) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun uninstall(pkg: String) {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun settings(panel: String) {
            val a = when (panel) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "sound" -> Settings.ACTION_SOUND_SETTINGS
                "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
                else -> Settings.ACTION_SETTINGS
            }
            startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun vibrate(ms: Long) {
            val v = getSystemService(Vibrator::class.java)
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }
}
